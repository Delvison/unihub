
package com.unihub.app;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.unihub.app package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetLocation_QNAME = new QName("http://app.unihub.com/", "getLocation");
    private final static QName _GetDateAndTimeResponse_QNAME = new QName("http://app.unihub.com/", "getDateAndTimeResponse");
    private final static QName _GetDateAndTime_QNAME = new QName("http://app.unihub.com/", "getDateAndTime");
    private final static QName _GetDescription_QNAME = new QName("http://app.unihub.com/", "getDescription");
    private final static QName _GetTitleResponse_QNAME = new QName("http://app.unihub.com/", "getTitleResponse");
    private final static QName _GetDescriptionResponse_QNAME = new QName("http://app.unihub.com/", "getDescriptionResponse");
    private final static QName _GetTitle_QNAME = new QName("http://app.unihub.com/", "getTitle");
    private final static QName _GetLocationResponse_QNAME = new QName("http://app.unihub.com/", "getLocationResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.unihub.app
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetDateAndTimeResponse }
     * 
     */
    public GetDateAndTimeResponse createGetDateAndTimeResponse() {
        return new GetDateAndTimeResponse();
    }

    /**
     * Create an instance of {@link GetLocationResponse }
     * 
     */
    public GetLocationResponse createGetLocationResponse() {
        return new GetLocationResponse();
    }

    /**
     * Create an instance of {@link GetTitleResponse }
     * 
     */
    public GetTitleResponse createGetTitleResponse() {
        return new GetTitleResponse();
    }

    /**
     * Create an instance of {@link GetDateAndTime }
     * 
     */
    public GetDateAndTime createGetDateAndTime() {
        return new GetDateAndTime();
    }

    /**
     * Create an instance of {@link GetLocation }
     * 
     */
    public GetLocation createGetLocation() {
        return new GetLocation();
    }

    /**
     * Create an instance of {@link GetTitle }
     * 
     */
    public GetTitle createGetTitle() {
        return new GetTitle();
    }

    /**
     * Create an instance of {@link GetDescriptionResponse }
     * 
     */
    public GetDescriptionResponse createGetDescriptionResponse() {
        return new GetDescriptionResponse();
    }

    /**
     * Create an instance of {@link GetDescription }
     * 
     */
    public GetDescription createGetDescription() {
        return new GetDescription();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLocation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getLocation")
    public JAXBElement<GetLocation> createGetLocation(GetLocation value) {
        return new JAXBElement<GetLocation>(_GetLocation_QNAME, GetLocation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDateAndTimeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDateAndTimeResponse")
    public JAXBElement<GetDateAndTimeResponse> createGetDateAndTimeResponse(GetDateAndTimeResponse value) {
        return new JAXBElement<GetDateAndTimeResponse>(_GetDateAndTimeResponse_QNAME, GetDateAndTimeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDateAndTime }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDateAndTime")
    public JAXBElement<GetDateAndTime> createGetDateAndTime(GetDateAndTime value) {
        return new JAXBElement<GetDateAndTime>(_GetDateAndTime_QNAME, GetDateAndTime.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDescription }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDescription")
    public JAXBElement<GetDescription> createGetDescription(GetDescription value) {
        return new JAXBElement<GetDescription>(_GetDescription_QNAME, GetDescription.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTitleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getTitleResponse")
    public JAXBElement<GetTitleResponse> createGetTitleResponse(GetTitleResponse value) {
        return new JAXBElement<GetTitleResponse>(_GetTitleResponse_QNAME, GetTitleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDescriptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDescriptionResponse")
    public JAXBElement<GetDescriptionResponse> createGetDescriptionResponse(GetDescriptionResponse value) {
        return new JAXBElement<GetDescriptionResponse>(_GetDescriptionResponse_QNAME, GetDescriptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getTitle")
    public JAXBElement<GetTitle> createGetTitle(GetTitle value) {
        return new JAXBElement<GetTitle>(_GetTitle_QNAME, GetTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLocationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getLocationResponse")
    public JAXBElement<GetLocationResponse> createGetLocationResponse(GetLocationResponse value) {
        return new JAXBElement<GetLocationResponse>(_GetLocationResponse_QNAME, GetLocationResponse.class, null, value);
    }

}
