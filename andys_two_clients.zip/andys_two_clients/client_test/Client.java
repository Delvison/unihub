import com.unihub.app.*;
import java.util.Scanner;

public class Client {


	public static void main(String[] args) {
		NakedEventsBeanService service = new NakedEventsBeanService();
		NakedEventsBean port = service.getNakedEventsBeanPort();
		
		System.out.println("Event 1 title is: "+ port.getTitle(1));
		System.out.println("Event 2 title is: "+ port.getDescription(2));		



	}




}
