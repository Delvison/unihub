import com.unihub.app.*;
import java.util.Scanner;

public class Client {


	public static void main(String[] args) {
		NakedAuthBeansService service = new NakedAuthBeansService();
		NakedAuthBeans port = service.getNakedAuthBeansPort();
		
		try {
			byte[] salt = port.getSalt("User1");
			if(port.authenticate("User1", "pass", salt)) {
				System.out.println("Successfully logged in!");
			}	
			else {
				System.out.println("Could not log on :(");
			}
		}
		catch(Exception e) {}



	}




}
