
package com.unihub.app;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.unihub.app package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Authenticate_QNAME = new QName("http://app.unihub.com/", "authenticate");
    private final static QName _GetSaltResponse_QNAME = new QName("http://app.unihub.com/", "getSaltResponse");
    private final static QName _NoSuchAlgorithmException_QNAME = new QName("http://app.unihub.com/", "NoSuchAlgorithmException");
    private final static QName _InvalidKeySpecException_QNAME = new QName("http://app.unihub.com/", "InvalidKeySpecException");
    private final static QName _GetSalt_QNAME = new QName("http://app.unihub.com/", "getSalt");
    private final static QName _AuthenticateResponse_QNAME = new QName("http://app.unihub.com/", "authenticateResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.unihub.app
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AuthenticateResponse }
     * 
     */
    public AuthenticateResponse createAuthenticateResponse() {
        return new AuthenticateResponse();
    }

    /**
     * Create an instance of {@link NoSuchAlgorithmException }
     * 
     */
    public NoSuchAlgorithmException createNoSuchAlgorithmException() {
        return new NoSuchAlgorithmException();
    }

    /**
     * Create an instance of {@link InvalidKeySpecException }
     * 
     */
    public InvalidKeySpecException createInvalidKeySpecException() {
        return new InvalidKeySpecException();
    }

    /**
     * Create an instance of {@link GetSaltResponse }
     * 
     */
    public GetSaltResponse createGetSaltResponse() {
        return new GetSaltResponse();
    }

    /**
     * Create an instance of {@link GetSalt }
     * 
     */
    public GetSalt createGetSalt() {
        return new GetSalt();
    }

    /**
     * Create an instance of {@link Authenticate }
     * 
     */
    public Authenticate createAuthenticate() {
        return new Authenticate();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Authenticate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "authenticate")
    public JAXBElement<Authenticate> createAuthenticate(Authenticate value) {
        return new JAXBElement<Authenticate>(_Authenticate_QNAME, Authenticate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSaltResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getSaltResponse")
    public JAXBElement<GetSaltResponse> createGetSaltResponse(GetSaltResponse value) {
        return new JAXBElement<GetSaltResponse>(_GetSaltResponse_QNAME, GetSaltResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoSuchAlgorithmException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "NoSuchAlgorithmException")
    public JAXBElement<NoSuchAlgorithmException> createNoSuchAlgorithmException(NoSuchAlgorithmException value) {
        return new JAXBElement<NoSuchAlgorithmException>(_NoSuchAlgorithmException_QNAME, NoSuchAlgorithmException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InvalidKeySpecException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "InvalidKeySpecException")
    public JAXBElement<InvalidKeySpecException> createInvalidKeySpecException(InvalidKeySpecException value) {
        return new JAXBElement<InvalidKeySpecException>(_InvalidKeySpecException_QNAME, InvalidKeySpecException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSalt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getSalt")
    public JAXBElement<GetSalt> createGetSalt(GetSalt value) {
        return new JAXBElement<GetSalt>(_GetSalt_QNAME, GetSalt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthenticateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "authenticateResponse")
    public JAXBElement<AuthenticateResponse> createAuthenticateResponse(AuthenticateResponse value) {
        return new JAXBElement<AuthenticateResponse>(_AuthenticateResponse_QNAME, AuthenticateResponse.class, null, value);
    }

}
