import com.unihub.app.*;
import java.util.Scanner;


public class UnihubClient{
  public static void main(String[] args){
    Scanner s = new Scanner(System.in);
    String input="";
    
    ListingSessionStatelessService c= new ListingSessionStatelessService();
    ListingSessionStateless lis = c.getListingSessionStatelessPort();

    while(!input.equals("quit")){
      System.out.print("Unihub 0.1 (type \"help\" for help) >> ");
      input = s.nextLine();

      if (input.equals("help")){
        System.out.println("Availible commands:");    
        System.out.println("--create\n--remove\n--view\n--quit\n");    
      }
      
      if (input.equals("remove")){
        System.out.print("Enter ID number >> ");
        int id = Integer.parseInt(s.nextLine());
        String a = lis.getName(id);
        lis.removeItem(id);
        System.out.print("Item "+a+" Removed.\n");
      }



      if (input.equals("create")){
        System.out.println("Creating a listing.\n\n");
        System.out.print("Username > ");
        String user = s.nextLine();
        System.out.print("Name of item > ");
        String name = s.nextLine();
        System.out.print("Price of item > ");
        String price = s.nextLine();
        System.out.print("University > ");
        String university = s.nextLine();
        System.out.print("location > ");
        String loc = s.nextLine();
        System.out.print("Category > ");
        String cat = s.nextLine();
        System.out.print("Description > ");
        String desc = s.nextLine();
        System.out.print("Bid Mode (yes or no) > ");
        String bid = s.nextLine();
        int currentId = lis.addStuff(user,name,price,university,loc,cat,desc,bid); 
        System.out.println("Listing succesfully posted with an id of "+ 
          Integer.toString(currentId));
      }

      if (input.equals("view")){
        System.out.print("Enter item ID > ");
        int id = Integer.parseInt(s.nextLine());
        String out = "\nName: "+lis.getName(id) + "\nPrice: "+
        lis.getPrice(id)+ "\nUniversity: "+lis.getUniversity(id)+
        "\n User: "+lis.getUser(id);
        System.out.println(out);
      }
    }
  }
}
