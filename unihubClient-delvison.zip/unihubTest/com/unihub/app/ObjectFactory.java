
package com.unihub.app;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.unihub.app package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetPriceResponse_QNAME = new QName("http://app.unihub.com/", "getPriceResponse");
    private final static QName _GetUser_QNAME = new QName("http://app.unihub.com/", "getUser");
    private final static QName _UpdateContentResponse_QNAME = new QName("http://app.unihub.com/", "updateContentResponse");
    private final static QName _GetDescription_QNAME = new QName("http://app.unihub.com/", "getDescription");
    private final static QName _ListingObjEJBStatelessResponse_QNAME = new QName("http://app.unihub.com/", "ListingObjEJBStatelessResponse");
    private final static QName _GetBidMode_QNAME = new QName("http://app.unihub.com/", "getBidMode");
    private final static QName _AddStuffResponse_QNAME = new QName("http://app.unihub.com/", "addStuffResponse");
    private final static QName _GetDir_QNAME = new QName("http://app.unihub.com/", "getDir");
    private final static QName _GetTimePostedResponse_QNAME = new QName("http://app.unihub.com/", "getTimePostedResponse");
    private final static QName _SetDir_QNAME = new QName("http://app.unihub.com/", "setDir");
    private final static QName _GetHighBidderResponse_QNAME = new QName("http://app.unihub.com/", "getHighBidderResponse");
    private final static QName _GetLocation_QNAME = new QName("http://app.unihub.com/", "getLocation");
    private final static QName _AddStuff_QNAME = new QName("http://app.unihub.com/", "addStuff");
    private final static QName _GetBidModeResponse_QNAME = new QName("http://app.unihub.com/", "getBidModeResponse");
    private final static QName _GetCategory_QNAME = new QName("http://app.unihub.com/", "getCategory");
    private final static QName _GetUniversity_QNAME = new QName("http://app.unihub.com/", "getUniversity");
    private final static QName _SetPicAmountResponse_QNAME = new QName("http://app.unihub.com/", "setPicAmountResponse");
    private final static QName _GetName_QNAME = new QName("http://app.unihub.com/", "getName");
    private final static QName _GetDescriptionResponse_QNAME = new QName("http://app.unihub.com/", "getDescriptionResponse");
    private final static QName _SetPicAmount_QNAME = new QName("http://app.unihub.com/", "setPicAmount");
    private final static QName _GetTimePosted_QNAME = new QName("http://app.unihub.com/", "getTimePosted");
    private final static QName _RemoveItem_QNAME = new QName("http://app.unihub.com/", "removeItem");
    private final static QName _GetPicAmountResponse_QNAME = new QName("http://app.unihub.com/", "getPicAmountResponse");
    private final static QName _GetPrice_QNAME = new QName("http://app.unihub.com/", "getPrice");
    private final static QName _GetIdResponse_QNAME = new QName("http://app.unihub.com/", "getIdResponse");
    private final static QName _ListingObjEJBStateless_QNAME = new QName("http://app.unihub.com/", "ListingObjEJBStateless");
    private final static QName _SetDirResponse_QNAME = new QName("http://app.unihub.com/", "setDirResponse");
    private final static QName _GetPicAmount_QNAME = new QName("http://app.unihub.com/", "getPicAmount");
    private final static QName _GetLocationResponse_QNAME = new QName("http://app.unihub.com/", "getLocationResponse");
    private final static QName _GetCategoryResponse_QNAME = new QName("http://app.unihub.com/", "getCategoryResponse");
    private final static QName _GetHighBidder_QNAME = new QName("http://app.unihub.com/", "getHighBidder");
    private final static QName _UpdateContent_QNAME = new QName("http://app.unihub.com/", "updateContent");
    private final static QName _GetNameResponse_QNAME = new QName("http://app.unihub.com/", "getNameResponse");
    private final static QName _GetUserResponse_QNAME = new QName("http://app.unihub.com/", "getUserResponse");
    private final static QName _GetUniversityResponse_QNAME = new QName("http://app.unihub.com/", "getUniversityResponse");
    private final static QName _RemoveItemResponse_QNAME = new QName("http://app.unihub.com/", "removeItemResponse");
    private final static QName _GetDirResponse_QNAME = new QName("http://app.unihub.com/", "getDirResponse");
    private final static QName _GetId_QNAME = new QName("http://app.unihub.com/", "getId");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.unihub.app
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RemoveItem }
     * 
     */
    public RemoveItem createRemoveItem() {
        return new RemoveItem();
    }

    /**
     * Create an instance of {@link GetPicAmountResponse }
     * 
     */
    public GetPicAmountResponse createGetPicAmountResponse() {
        return new GetPicAmountResponse();
    }

    /**
     * Create an instance of {@link GetPrice }
     * 
     */
    public GetPrice createGetPrice() {
        return new GetPrice();
    }

    /**
     * Create an instance of {@link ListingObjEJBStateless }
     * 
     */
    public ListingObjEJBStateless createListingObjEJBStateless() {
        return new ListingObjEJBStateless();
    }

    /**
     * Create an instance of {@link GetIdResponse }
     * 
     */
    public GetIdResponse createGetIdResponse() {
        return new GetIdResponse();
    }

    /**
     * Create an instance of {@link SetDirResponse }
     * 
     */
    public SetDirResponse createSetDirResponse() {
        return new SetDirResponse();
    }

    /**
     * Create an instance of {@link GetPicAmount }
     * 
     */
    public GetPicAmount createGetPicAmount() {
        return new GetPicAmount();
    }

    /**
     * Create an instance of {@link GetLocationResponse }
     * 
     */
    public GetLocationResponse createGetLocationResponse() {
        return new GetLocationResponse();
    }

    /**
     * Create an instance of {@link GetCategoryResponse }
     * 
     */
    public GetCategoryResponse createGetCategoryResponse() {
        return new GetCategoryResponse();
    }

    /**
     * Create an instance of {@link GetHighBidder }
     * 
     */
    public GetHighBidder createGetHighBidder() {
        return new GetHighBidder();
    }

    /**
     * Create an instance of {@link UpdateContent }
     * 
     */
    public UpdateContent createUpdateContent() {
        return new UpdateContent();
    }

    /**
     * Create an instance of {@link GetNameResponse }
     * 
     */
    public GetNameResponse createGetNameResponse() {
        return new GetNameResponse();
    }

    /**
     * Create an instance of {@link GetUserResponse }
     * 
     */
    public GetUserResponse createGetUserResponse() {
        return new GetUserResponse();
    }

    /**
     * Create an instance of {@link GetUniversityResponse }
     * 
     */
    public GetUniversityResponse createGetUniversityResponse() {
        return new GetUniversityResponse();
    }

    /**
     * Create an instance of {@link RemoveItemResponse }
     * 
     */
    public RemoveItemResponse createRemoveItemResponse() {
        return new RemoveItemResponse();
    }

    /**
     * Create an instance of {@link GetDirResponse }
     * 
     */
    public GetDirResponse createGetDirResponse() {
        return new GetDirResponse();
    }

    /**
     * Create an instance of {@link GetId }
     * 
     */
    public GetId createGetId() {
        return new GetId();
    }

    /**
     * Create an instance of {@link GetPriceResponse }
     * 
     */
    public GetPriceResponse createGetPriceResponse() {
        return new GetPriceResponse();
    }

    /**
     * Create an instance of {@link GetUser }
     * 
     */
    public GetUser createGetUser() {
        return new GetUser();
    }

    /**
     * Create an instance of {@link UpdateContentResponse }
     * 
     */
    public UpdateContentResponse createUpdateContentResponse() {
        return new UpdateContentResponse();
    }

    /**
     * Create an instance of {@link GetDescription }
     * 
     */
    public GetDescription createGetDescription() {
        return new GetDescription();
    }

    /**
     * Create an instance of {@link ListingObjEJBStatelessResponse }
     * 
     */
    public ListingObjEJBStatelessResponse createListingObjEJBStatelessResponse() {
        return new ListingObjEJBStatelessResponse();
    }

    /**
     * Create an instance of {@link GetBidMode }
     * 
     */
    public GetBidMode createGetBidMode() {
        return new GetBidMode();
    }

    /**
     * Create an instance of {@link AddStuffResponse }
     * 
     */
    public AddStuffResponse createAddStuffResponse() {
        return new AddStuffResponse();
    }

    /**
     * Create an instance of {@link GetDir }
     * 
     */
    public GetDir createGetDir() {
        return new GetDir();
    }

    /**
     * Create an instance of {@link SetDir }
     * 
     */
    public SetDir createSetDir() {
        return new SetDir();
    }

    /**
     * Create an instance of {@link GetTimePostedResponse }
     * 
     */
    public GetTimePostedResponse createGetTimePostedResponse() {
        return new GetTimePostedResponse();
    }

    /**
     * Create an instance of {@link GetHighBidderResponse }
     * 
     */
    public GetHighBidderResponse createGetHighBidderResponse() {
        return new GetHighBidderResponse();
    }

    /**
     * Create an instance of {@link GetLocation }
     * 
     */
    public GetLocation createGetLocation() {
        return new GetLocation();
    }

    /**
     * Create an instance of {@link AddStuff }
     * 
     */
    public AddStuff createAddStuff() {
        return new AddStuff();
    }

    /**
     * Create an instance of {@link GetCategory }
     * 
     */
    public GetCategory createGetCategory() {
        return new GetCategory();
    }

    /**
     * Create an instance of {@link GetBidModeResponse }
     * 
     */
    public GetBidModeResponse createGetBidModeResponse() {
        return new GetBidModeResponse();
    }

    /**
     * Create an instance of {@link SetPicAmountResponse }
     * 
     */
    public SetPicAmountResponse createSetPicAmountResponse() {
        return new SetPicAmountResponse();
    }

    /**
     * Create an instance of {@link GetUniversity }
     * 
     */
    public GetUniversity createGetUniversity() {
        return new GetUniversity();
    }

    /**
     * Create an instance of {@link GetDescriptionResponse }
     * 
     */
    public GetDescriptionResponse createGetDescriptionResponse() {
        return new GetDescriptionResponse();
    }

    /**
     * Create an instance of {@link GetName }
     * 
     */
    public GetName createGetName() {
        return new GetName();
    }

    /**
     * Create an instance of {@link SetPicAmount }
     * 
     */
    public SetPicAmount createSetPicAmount() {
        return new SetPicAmount();
    }

    /**
     * Create an instance of {@link GetTimePosted }
     * 
     */
    public GetTimePosted createGetTimePosted() {
        return new GetTimePosted();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPriceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getPriceResponse")
    public JAXBElement<GetPriceResponse> createGetPriceResponse(GetPriceResponse value) {
        return new JAXBElement<GetPriceResponse>(_GetPriceResponse_QNAME, GetPriceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getUser")
    public JAXBElement<GetUser> createGetUser(GetUser value) {
        return new JAXBElement<GetUser>(_GetUser_QNAME, GetUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateContentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "updateContentResponse")
    public JAXBElement<UpdateContentResponse> createUpdateContentResponse(UpdateContentResponse value) {
        return new JAXBElement<UpdateContentResponse>(_UpdateContentResponse_QNAME, UpdateContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDescription }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDescription")
    public JAXBElement<GetDescription> createGetDescription(GetDescription value) {
        return new JAXBElement<GetDescription>(_GetDescription_QNAME, GetDescription.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListingObjEJBStatelessResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "ListingObjEJBStatelessResponse")
    public JAXBElement<ListingObjEJBStatelessResponse> createListingObjEJBStatelessResponse(ListingObjEJBStatelessResponse value) {
        return new JAXBElement<ListingObjEJBStatelessResponse>(_ListingObjEJBStatelessResponse_QNAME, ListingObjEJBStatelessResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBidMode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getBidMode")
    public JAXBElement<GetBidMode> createGetBidMode(GetBidMode value) {
        return new JAXBElement<GetBidMode>(_GetBidMode_QNAME, GetBidMode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddStuffResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "addStuffResponse")
    public JAXBElement<AddStuffResponse> createAddStuffResponse(AddStuffResponse value) {
        return new JAXBElement<AddStuffResponse>(_AddStuffResponse_QNAME, AddStuffResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDir }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDir")
    public JAXBElement<GetDir> createGetDir(GetDir value) {
        return new JAXBElement<GetDir>(_GetDir_QNAME, GetDir.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTimePostedResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getTimePostedResponse")
    public JAXBElement<GetTimePostedResponse> createGetTimePostedResponse(GetTimePostedResponse value) {
        return new JAXBElement<GetTimePostedResponse>(_GetTimePostedResponse_QNAME, GetTimePostedResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDir }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "setDir")
    public JAXBElement<SetDir> createSetDir(SetDir value) {
        return new JAXBElement<SetDir>(_SetDir_QNAME, SetDir.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetHighBidderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getHighBidderResponse")
    public JAXBElement<GetHighBidderResponse> createGetHighBidderResponse(GetHighBidderResponse value) {
        return new JAXBElement<GetHighBidderResponse>(_GetHighBidderResponse_QNAME, GetHighBidderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLocation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getLocation")
    public JAXBElement<GetLocation> createGetLocation(GetLocation value) {
        return new JAXBElement<GetLocation>(_GetLocation_QNAME, GetLocation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddStuff }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "addStuff")
    public JAXBElement<AddStuff> createAddStuff(AddStuff value) {
        return new JAXBElement<AddStuff>(_AddStuff_QNAME, AddStuff.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBidModeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getBidModeResponse")
    public JAXBElement<GetBidModeResponse> createGetBidModeResponse(GetBidModeResponse value) {
        return new JAXBElement<GetBidModeResponse>(_GetBidModeResponse_QNAME, GetBidModeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCategory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getCategory")
    public JAXBElement<GetCategory> createGetCategory(GetCategory value) {
        return new JAXBElement<GetCategory>(_GetCategory_QNAME, GetCategory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUniversity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getUniversity")
    public JAXBElement<GetUniversity> createGetUniversity(GetUniversity value) {
        return new JAXBElement<GetUniversity>(_GetUniversity_QNAME, GetUniversity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetPicAmountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "setPicAmountResponse")
    public JAXBElement<SetPicAmountResponse> createSetPicAmountResponse(SetPicAmountResponse value) {
        return new JAXBElement<SetPicAmountResponse>(_SetPicAmountResponse_QNAME, SetPicAmountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getName")
    public JAXBElement<GetName> createGetName(GetName value) {
        return new JAXBElement<GetName>(_GetName_QNAME, GetName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDescriptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDescriptionResponse")
    public JAXBElement<GetDescriptionResponse> createGetDescriptionResponse(GetDescriptionResponse value) {
        return new JAXBElement<GetDescriptionResponse>(_GetDescriptionResponse_QNAME, GetDescriptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetPicAmount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "setPicAmount")
    public JAXBElement<SetPicAmount> createSetPicAmount(SetPicAmount value) {
        return new JAXBElement<SetPicAmount>(_SetPicAmount_QNAME, SetPicAmount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTimePosted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getTimePosted")
    public JAXBElement<GetTimePosted> createGetTimePosted(GetTimePosted value) {
        return new JAXBElement<GetTimePosted>(_GetTimePosted_QNAME, GetTimePosted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveItem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "removeItem")
    public JAXBElement<RemoveItem> createRemoveItem(RemoveItem value) {
        return new JAXBElement<RemoveItem>(_RemoveItem_QNAME, RemoveItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPicAmountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getPicAmountResponse")
    public JAXBElement<GetPicAmountResponse> createGetPicAmountResponse(GetPicAmountResponse value) {
        return new JAXBElement<GetPicAmountResponse>(_GetPicAmountResponse_QNAME, GetPicAmountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPrice }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getPrice")
    public JAXBElement<GetPrice> createGetPrice(GetPrice value) {
        return new JAXBElement<GetPrice>(_GetPrice_QNAME, GetPrice.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getIdResponse")
    public JAXBElement<GetIdResponse> createGetIdResponse(GetIdResponse value) {
        return new JAXBElement<GetIdResponse>(_GetIdResponse_QNAME, GetIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListingObjEJBStateless }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "ListingObjEJBStateless")
    public JAXBElement<ListingObjEJBStateless> createListingObjEJBStateless(ListingObjEJBStateless value) {
        return new JAXBElement<ListingObjEJBStateless>(_ListingObjEJBStateless_QNAME, ListingObjEJBStateless.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDirResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "setDirResponse")
    public JAXBElement<SetDirResponse> createSetDirResponse(SetDirResponse value) {
        return new JAXBElement<SetDirResponse>(_SetDirResponse_QNAME, SetDirResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPicAmount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getPicAmount")
    public JAXBElement<GetPicAmount> createGetPicAmount(GetPicAmount value) {
        return new JAXBElement<GetPicAmount>(_GetPicAmount_QNAME, GetPicAmount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLocationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getLocationResponse")
    public JAXBElement<GetLocationResponse> createGetLocationResponse(GetLocationResponse value) {
        return new JAXBElement<GetLocationResponse>(_GetLocationResponse_QNAME, GetLocationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCategoryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getCategoryResponse")
    public JAXBElement<GetCategoryResponse> createGetCategoryResponse(GetCategoryResponse value) {
        return new JAXBElement<GetCategoryResponse>(_GetCategoryResponse_QNAME, GetCategoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetHighBidder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getHighBidder")
    public JAXBElement<GetHighBidder> createGetHighBidder(GetHighBidder value) {
        return new JAXBElement<GetHighBidder>(_GetHighBidder_QNAME, GetHighBidder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateContent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "updateContent")
    public JAXBElement<UpdateContent> createUpdateContent(UpdateContent value) {
        return new JAXBElement<UpdateContent>(_UpdateContent_QNAME, UpdateContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getNameResponse")
    public JAXBElement<GetNameResponse> createGetNameResponse(GetNameResponse value) {
        return new JAXBElement<GetNameResponse>(_GetNameResponse_QNAME, GetNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUserResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getUserResponse")
    public JAXBElement<GetUserResponse> createGetUserResponse(GetUserResponse value) {
        return new JAXBElement<GetUserResponse>(_GetUserResponse_QNAME, GetUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUniversityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getUniversityResponse")
    public JAXBElement<GetUniversityResponse> createGetUniversityResponse(GetUniversityResponse value) {
        return new JAXBElement<GetUniversityResponse>(_GetUniversityResponse_QNAME, GetUniversityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveItemResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "removeItemResponse")
    public JAXBElement<RemoveItemResponse> createRemoveItemResponse(RemoveItemResponse value) {
        return new JAXBElement<RemoveItemResponse>(_RemoveItemResponse_QNAME, RemoveItemResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDirResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getDirResponse")
    public JAXBElement<GetDirResponse> createGetDirResponse(GetDirResponse value) {
        return new JAXBElement<GetDirResponse>(_GetDirResponse_QNAME, GetDirResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://app.unihub.com/", name = "getId")
    public JAXBElement<GetId> createGetId(GetId value) {
        return new JAXBElement<GetId>(_GetId_QNAME, GetId.class, null, value);
    }

}
